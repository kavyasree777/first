﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Basic_Operation;
using Data_Acess;
using Bussiness_Class;

namespace Final_Project
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        BLLMaintenance obj_bll = new BLLMaintenance();
        BO_ASV obj_bo = new BO_ASV();


        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                if (Session["user"] == null)
                {
                    Server.Transfer("LoginPage.aspx");
                    //Response.Write("<script>alert('Your Session is Expired,Please Login Again')<script>");
                }
                else
                {

                    GridView1.DataSource = obj_bll.ASV_Viewing();
                    GridView1.DataBind();

                }

                Label10.Text = "";
            }
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

            GridView1.EditIndex = -1;
            GridView1.DataSource = obj_bll.ASV_Viewing();
            GridView1.DataBind();


        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            Label l = GridView1.Rows[e.RowIndex].FindControl("Label1") as Label;
            int id = Convert.ToInt32(l.Text);


            obj_bll.ASV_Deleting(id);

            {
                GridView1.DataSource = obj_bll.ASV_Viewing();
                GridView1.DataBind();
                GridView1.EditIndex = -1;
            }

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            TextBox a = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;//id
            TextBox f = GridView1.Rows[e.RowIndex].FindControl("TextBox6") as TextBox;//contact no
            TextBox g = GridView1.Rows[e.RowIndex].FindControl("TextBox7") as TextBox;//email
            DropDownList h = GridView1.Rows[e.RowIndex].FindControl("DropDownlist2") as DropDownList;//c.level
            TextBox b = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;//name
            DropDownList c = GridView1.Rows[e.RowIndex].FindControl("DropDownList3") as DropDownList;//region
            TextBox d = GridView1.Rows[e.RowIndex].FindControl("TextBox4") as TextBox;//address
            TextBox e1 = GridView1.Rows[e.RowIndex].FindControl("TextBox5") as TextBox;//country
            //obj_bo.ASVid = a.Text;
            obj_bo.ASVName = b.Text;
            obj_bo.ASVRegion = c.Text;
            obj_bo.ASVAddress = d.Text;
            obj_bo.ASVCountry = e1.Text;
            obj_bo.ASVContactNo = Convert.ToInt64(f.Text);
            obj_bo.ASVEmail = g.Text;
            obj_bo.ASVCompetency = h.Text;

            bool y = obj_bll.ASV_Editing(obj_bo);
            if (y == true)
            {
                
                GridView1.EditIndex = -1;
                GridView1.DataSource = obj_bll.ASV_Viewing();
                GridView1.DataBind();
                Response.Write("<script>alert('Deleted Successfully')</script>");

            }



        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "ASV ID")
            {
                List<BO_ASV> alist = new List<BO_ASV>();
                int id = Convert.ToInt32(TextBox9.Text);
                obj_bo.ASVid = id;
                obj_bo.ASVCountry = null;
                obj_bo.ASVCompetency = null;
                alist = obj_bll.Search_ASV(obj_bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }

            else if (DropDownList1.SelectedValue == "Region")
                {
                    List<BO_ASV> alist = new List<BO_ASV>();
                    string region = (TextBox9.Text);
                    obj_bo.ASVRegion = region;
                    alist = obj_bll.Search_ASV(obj_bo);
                    GridView1.DataSource = alist;
                    GridView1.DataBind();

                }

            else if (DropDownList1.SelectedValue == "Competency Level")
                {
                        List<BO_ASV> alist = new List<BO_ASV>();
                        string region = (TextBox9.Text);
                        obj_bo.ASVCompetency = region;
                        alist = obj_bll.Search_ASV(obj_bo);
                        GridView1.DataSource = alist;
                        GridView1.DataBind();

                 }
            else if (DropDownList1.SelectedValue == "--Select--")
            {
                Response.Write("<script>alert('Please Select an option to Search')</script>");
            }
            }
        }
    }



