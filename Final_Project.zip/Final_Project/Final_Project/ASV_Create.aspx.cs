﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Bussiness_Class;
using Basic_Operation;

namespace Final_Project
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        BLLMaintenance obj_bll = new BLLMaintenance();
       BO_ASV obj_bo_ASV = new BO_ASV();
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            DropDownList1.SelectedIndex = 0;
            DropDownList2.Text = "";
            TextBox5.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox3.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            obj_bo_ASV.ASVName = TextBox2.Text.Trim();
            obj_bo_ASV.ASVRegion = DropDownList2.Text.Trim();
            obj_bo_ASV.ASVAddress = TextBox2.Text.Trim();
            obj_bo_ASV.ASVCountry = TextBox4.Text.Trim();
            obj_bo_ASV.ASVContactNo =Convert.ToInt64(TextBox5.Text);
            obj_bo_ASV.ASVCompetency = DropDownList1.SelectedValue;

            int res = obj_bll.ASV_addition(obj_bo_ASV);

            if (res != 0)
            {
                Response.Write("<script>alert('ASV is registered successfully with id" + obj_bo_ASV.ASVid + "')</script>");
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Text = "";
                TextBox5.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox3.Text = "";
            }

            else
            {
                Response.Write("<script>alert('ASV is not registered successfully. Try Again !!')</script>");
                DropDownList1.SelectedIndex = 0;
                DropDownList2.Text = "";
                TextBox5.Text = "";
                TextBox2.Text = "";
                TextBox4.Text = "";
                TextBox3.Text = "";
            }


        }
    }
}