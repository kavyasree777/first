﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data;
using Basic_Operation;
using Bussiness_Class;
using Data_Acess;


namespace Final_Project
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        BLLMaintenance obj_bll = new BLLMaintenance();
        BO_RCM obj_bo = new BO_RCM();


        SqlConnection con = new SqlConnection("data source=172.25.192.80; initial catalog=DB01HMS22; uid=pj01HMS22; pwd=tcshyd");
        SqlCommand cmd = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["user"] == null)
                {
                    Server.Transfer("LoginPage.aspx");
                    //Response.Write("<script>alert('Your Session is Expired,Please Login Again')<script>");
                }
                GridView1.DataSource = obj_bll.View_RCM_Details(obj_bo);
                GridView1.DataBind();

            }
            Label9.Text = "";
        }

        protected void GridView1Editing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            SqlCommand cmd = new SqlCommand("usp_UpdateASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            GridView1.DataSource = cmd.ExecuteReader();
            GridView1.DataBind();
            con.Close();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label l = GridView1.Rows[e.RowIndex].FindControl("Label1") as Label;
            obj_bo.RCMId = Convert.ToInt32(l.Text);
            bool o = obj_bll.Delete_RCM_Details(obj_bo);
            if (o == true)
            {

                GridView1.EditIndex = -1;
                GridView1.DataSource = obj_bll.View_RCM_Details(obj_bo);
                GridView1.DataBind();

            }
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = obj_bll.View_RCM_Details(obj_bo);
            GridView1.DataBind();

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            TextBox a = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
            TextBox b = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;
            TextBox c = GridView1.Rows[e.RowIndex].FindControl("TextBox3") as TextBox;
            TextBox d = GridView1.Rows[e.RowIndex].FindControl("TextBox4") as TextBox;
            TextBox i = GridView1.Rows[e.RowIndex].FindControl("TextBox5") as TextBox;
            DropDownList f = GridView1.Rows[e.RowIndex].FindControl("DropDownList2") as DropDownList;
            //TextBox g = GridView1.Rows[e.RowIndex].FindControl("TextBox7") as TextBox;
            //obj_rcm.Rcm_id = a.Text;
            obj_bo.Region = a.Text;
            obj_bo.Name = b.Text;
            obj_bo.DateOfJoining = Convert.ToDateTime(c.Text);
            obj_bo.Email = d.Text;
            obj_bo.ContactAddress = i.Text;
            obj_bo.Countries = f.Text;
            bool y = obj_bll.Update_RCM_Details(obj_bo);
            if (y == true)
            {
                //Response.Write("<script>alert('Deleted Successfully')</script>");
                GridView1.EditIndex = -1;
                GridView1.DataSource = obj_bll.View_RCM_Details(obj_bo);
                GridView1.DataBind();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedValue=="RCM Id")
            {
                //Session["value"] = "Enter the RCM ID";
                Label9.Text = "Enter the RCM ID";
            }


            else
            {
                if (DropDownList1.SelectedValue == "Region")
                {
                    //Session["value"] = "Enter the RCM ID";
                    Label9.Text = "Enter the Region";
                }

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //string search = TextBox7.Text.ToString();
           

            if (DropDownList1.SelectedValue == "RCM Id")
            {
                List<BO_RCM> alist = new List<BO_RCM>();
                int id = Convert.ToInt32(TextBox7.Text);
                obj_bo.RCMId = id;
                alist = obj_bll.Search_RCM_Details(obj_bo);
                GridView1.DataSource = alist;
                GridView1.DataBind();

            }

            else
            {

                if (DropDownList1.SelectedValue == "Region")
                {
                    List<BO_RCM> alist = new List<BO_RCM>();
                    string region =(TextBox7.Text);
                    obj_bo.Region = region;
                    alist = obj_bll.Search_RCM_Details(obj_bo);
                    GridView1.DataSource = alist;
                    GridView1.DataBind();

                }

            }
            
        }
    }
}

            

        
    
    
