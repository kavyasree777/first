﻿using Basic_Operation;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Acess
{
    public class DAL
    {
        string str = "server=172.25.192.80;database=DB01HMS22;uid=PJ01HMS22;pwd=tcshyd";
        SqlConnection con;
        SqlCommand cmd;

        ///////////////////////////To add Rcm Details to Database///////////////////////////////////

        public int Add_RCM_Details(BO_RCM bo)
        {
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_RCMCreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RCMId", bo.RCMId);
            cmd.Parameters.AddWithValue("@Region", bo.Region);
            cmd.Parameters.AddWithValue("@Name", bo.Name);
            cmd.Parameters.AddWithValue("@Pasword", bo.Passord);
            cmd.Parameters.AddWithValue("@DateofJoining", bo.DateOfJoining);
            cmd.Parameters.AddWithValue("@Email", bo.Email);
            cmd.Parameters.AddWithValue("@ContactAddress", bo.ContactAddress);
            cmd.Parameters.AddWithValue("@Countries", bo.Countries);
            cmd.Parameters.AddWithValue("@IsActive", bo.IsActive);

            cmd.Parameters["@RCMId"].Direction = ParameterDirection.Output;
            int rowaffected = cmd.ExecuteNonQuery();
            if (rowaffected != 0)
            {
                return Convert.ToInt32(cmd.Parameters["@RCMId"].Value);
            }
            else
            {
                return 0;
            }
        }

        ///////////////////////////To Edit Rcm Details to Database///////////////////////////////////////

        public bool Update_RCM_Details(BO_RCM bo)
        {
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_updateRCM", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            //cmd.Parameters.AddWithValue("@RCMId", bo.RCMId);
            cmd.Parameters.AddWithValue("@Region", bo.Region);
            cmd.Parameters.AddWithValue("@Name", bo.Name);
            cmd.Parameters.AddWithValue("@Pasword", bo.Passord);
            cmd.Parameters.AddWithValue("@DateofJoining", bo.DateOfJoining);
            cmd.Parameters.AddWithValue("@Email", bo.Email);
            cmd.Parameters.AddWithValue("@ContactAddress", bo.ContactAddress);
            cmd.Parameters.AddWithValue("@Countries", bo.Countries);
            cmd.Parameters.AddWithValue("@IsActive", bo.IsActive);


            int rowaffected = cmd.ExecuteNonQuery();
            if (rowaffected != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //////////////////////Search any RCM Details in Database depending on RCMId or Region //////////////////////////////////////
        public List<BO_RCM> Search_RCM_Details(BO_RCM bo)
        {

            List<BO_RCM> list = new List<BO_RCM>();
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_viewRCM", con);
            cmd.CommandType = CommandType.StoredProcedure;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            cmd.Parameters.AddWithValue("@RCMId", bo.RCMId);
            cmd.Parameters.AddWithValue("@Region", bo.Region);
            //cmd.Parameters.AddWithValue("@IsActive", bo.IsActive);

            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    BO_RCM tempBo = new BO_RCM();
                    tempBo.RCMId = Convert.ToInt32(rd["RCMId"]);
                    tempBo.Region = rd["Region"].ToString();
                    tempBo.Name = rd["Name"].ToString();
                    tempBo.Passord = rd["Password"].ToString();
                    tempBo.DateOfJoining = Convert.ToDateTime(rd["DateOfJoining"]);
                    tempBo.Email = rd["Email"].ToString();
                    tempBo.ContactAddress = rd["ContactAddress"].ToString();
                    tempBo.Countries = rd["Countries"].ToString();
                    tempBo.IsActive = Convert.ToBoolean(rd["IsActive"]);
                    list.Add(tempBo);
                }
            }

            return list;

        }

 //////////////////////View RCM Details in Database which are active //////////////////////////////////////
        public List<BO_RCM> View_RCM_Details(BO_RCM bo)
        {
            List<BO_RCM> list = new List<BO_RCM>();
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_viewAllRCM", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            cmd.Parameters.AddWithValue("@IsActive", true);
            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    BO_RCM tempBo = new BO_RCM();
                    tempBo.RCMId = Convert.ToInt32(rd["RCMId"]);
                    tempBo.Region = rd["Region"].ToString();
                    tempBo.Name = rd["Name"].ToString();
                    tempBo.Passord = rd["Password"].ToString();
                    tempBo.DateOfJoining = Convert.ToDateTime(rd["DateOfJoining"]);
                    tempBo.Email = rd["Email"].ToString();
                    tempBo.ContactAddress = rd["ContactAddress"].ToString();
                    tempBo.Countries = rd["Countries"].ToString();
                    tempBo.IsActive = Convert.ToBoolean(rd["IsActive"]);
                    list.Add(tempBo);
                }
            }

            return list;
        }
 ///////////////////////////To delete Rcm Details from Database///////////////////////////////////////
        public bool Delete_RCM_Details(BO_RCM bo)
        {

            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_deleteRCM", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            cmd.Parameters.AddWithValue("@RCMId", bo.RCMId);
            int rowUpdate = cmd.ExecuteNonQuery();
            con.Close();
            if (rowUpdate != 0)
            {
                return (true);
            }
            else
            {
                return (false);
            }

        }


        ///////////////////////////////////////ASV ADD ///////////////////////////////////////

         public int AddASV(BO_ASV a)
        {
            int id = 0;
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_ASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;

            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            cmd.Parameters.AddWithValue("@ASVId", 0);
            cmd.Parameters.AddWithValue("@Name", a.ASVName);
            cmd.Parameters.AddWithValue("@Password1", a.ASVPassword1);
            cmd.Parameters.AddWithValue("@Region", a.ASVRegion);
            cmd.Parameters.AddWithValue("@Adress", a.ASVAddress);
            cmd.Parameters.AddWithValue("@Country", a.ASVCountry);
            cmd.Parameters.AddWithValue("@Contactnumber", a.ASVContactNo);
            cmd.Parameters.AddWithValue("@Emailaddress", a.ASVEmail);
            cmd.Parameters.AddWithValue("@Competencylevel", a.ASVCompetency);
            cmd.Parameters.AddWithValue("@IsActive", 1);
            cmd.Parameters["@ASVId"].Direction = ParameterDirection.Output;
            
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
            {
                id = Convert.ToInt32(cmd.Parameters["@ASVId"].Value);
            }
            else
            {
                id = 0;
            }
            con.Close();
            return id;

        }
         ///////////////////////////////////// ASV Edit////////////////////////////////////

         public bool ASV_Edit(BO_ASV b)
         {
             con = new SqlConnection(str);
             cmd = new SqlCommand("usp_UpdateASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
             if (con.State == ConnectionState.Closed)
             {
                 con.Open();
             }

             cmd.Parameters.AddWithValue("@Name ", b.ASVName);
             cmd.Parameters.AddWithValue("@Password1", b.ASVPassword1);
             cmd.Parameters.AddWithValue("@Region", b.ASVRegion);
             cmd.Parameters.AddWithValue("@Adress", b.ASVAddress);
             cmd.Parameters.AddWithValue("@Country", b.ASVCountry);
             cmd.Parameters.AddWithValue("@Contactnumber", b.ASVContactNo);
             cmd.Parameters.AddWithValue("@Emailaddress", b.ASVEmail);
             cmd.Parameters.AddWithValue("@Competencylevel", b.ASVCompetency);
             cmd.Parameters.AddWithValue("@IsActive", 1);

             
             int rowaffected = cmd.ExecuteNonQuery();
             con.Close();
             if (rowaffected != 0)
             {
                 return true;
             }
             else
             {
                 return false;
             }
         }

        ///////////////////////////////////// ASV View////////////////////////////////////

        public List<BO_ASV> ViewASV()
        {
            List<BO_ASV> bo = new List<BO_ASV>();
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_ViewAllASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
          
            cmd.Parameters.AddWithValue("@IsActive", true);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                while (rd.Read())
                {
                    BO_ASV b = new BO_ASV();

                    b.ASVid = Convert.ToInt32(rd["ASVid"].ToString());
                    b.ASVName = rd["ASVName"].ToString();
                    b.ASVPassword1 = rd["ASVPassword1"].ToString();
                    b.ASVRegion = rd["ASVRegion"].ToString();
                    b.ASVAddress = rd["ASVAddress"].ToString();
                    b.ASVCountry = rd["ASVCountry"].ToString();
                    b.ASVContactNo = Convert.ToInt32(rd["ASVContactNo"].ToString());
                    b.ASVEmail = rd["ASVEmail"].ToString();
                    b.ASVCompetency = rd["ASVCompetency"].ToString();
                    b.ASVActive = Convert.ToBoolean(rd["ASVActive"].ToString());

                    bo.Add(b);
                }
            }
            con.Close();
            return bo;
        }

        ///////////////////////////////////// ASV Search////////////////////////////////////
        public List<BO_ASV> Search_ASV(BO_ASV bo)
        {
            List<BO_ASV> obj = new List<BO_ASV>();
            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_ViewASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            cmd.Parameters.AddWithValue("@ASVid", bo.ASVid);
            cmd.Parameters.AddWithValue("@Country", bo.ASVCountry);
            cmd.Parameters.AddWithValue("@Competencylevel", bo.ASVCompetency);
            SqlDataReader reader;
            reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {

                while (reader.Read())
                {
                    int ASVid = Convert.ToInt32(reader["ASVid "]);
                    string asvName = reader["Name"].ToString();
                    string ASVPassword1 = reader["ASVPassword1"].ToString();
                    string ASVRegion = reader["ASVRegion"].ToString();
                    string ASVAdress = reader["ASVAdress"].ToString();
                    string ASVCountry = reader["ASVCountry"].ToString();
                    long ASVContactNo = Convert.ToInt64(reader["ASVContactNo"]);
                    string ASVEmail = reader["ASVEmail"].ToString();
                    string ASVCompetency = reader["ASVCompetency"].ToString();
                    bool ASVActive = Convert.ToBoolean(reader["ASVActive"]);

                    BO_ASV b1 = new BO_ASV(ASVid, asvName, ASVPassword1, ASVRegion, ASVAdress, ASVCountry, ASVContactNo, ASVEmail, ASVCompetency, ASVActive);
                    obj.Add(b1);
                }
               
            }
            con.Close();

            return obj;
        }




        ///////////////////////////////////// ASV Delete////////////////////////////////////
        public bool DeleteASV(int ASVid)
        {

            con = new SqlConnection(str);
            cmd = new SqlCommand("usp_DELETEASVcreation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@ASVid", ASVid);
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }

            int rowUpdate = cmd.ExecuteNonQuery();
            con.Close();
            if (rowUpdate != 0)
            {
                return (true);
            }
            else
            {
                return (false);
            }
        }


        //////////////////////////////////////Warrenty add/////////////////////////////////////


        public int adddetails(BO_Warranty b)
        {
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_tbl_WarrantyMaintenance", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State != ConnectionState.Open)
                con.Open();
            cmd.Parameters.AddWithValue("@DeviceName", b.DeviceName);
            cmd.Parameters.AddWithValue("@ModelNo", b.ModelNo);
            cmd.Parameters.AddWithValue("@DeviceType", b.DeviceType);
            cmd.Parameters.AddWithValue("@IMEINumber", b.IMEI);
            cmd.Parameters.AddWithValue("@DateofManufacture", b.DateOfManufacture);
            cmd.Parameters.AddWithValue("@DateOfShipping", b.DateOfShipping);
            cmd.Parameters.AddWithValue("@DateofWarrantyExpiry", b.DateOfWarrantyExp);
            cmd.Parameters.AddWithValue("@InWarranty", b.InWarranty);
            cmd.Parameters.AddWithValue("@Price", b.Price);
            cmd.Parameters.AddWithValue("@SpecialWarranty", b.SpecialWarranty);
            cmd.Parameters.AddWithValue("@IsActive", b.IsActive);
            SqlParameter k = new SqlParameter("@Deviceid", SqlDbType.Int);
            k.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            con.Close();
            return (int)k.Value;
        }
        //////////////////////////////////////Warrenty update/////////////////////////////////////
        public bool updatedetails(BO_Warranty b)
        {
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_EditWarrantyMaintenance", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State != ConnectionState.Open)
                con.Open();
            cmd.Parameters.AddWithValue("@DeviceName", b.DeviceName);
            cmd.Parameters.AddWithValue("@ModelNo", b.ModelNo);
            cmd.Parameters.AddWithValue("@DeviceType", b.DeviceType);
            cmd.Parameters.AddWithValue("@IMEINumber", b.IMEI);
            cmd.Parameters.AddWithValue("@DateofManufacture", b.DateOfManufacture);
            cmd.Parameters.AddWithValue("@DateOfShipping", b.DateOfShipping);
            cmd.Parameters.AddWithValue("@DateofWarrantyExpiry", b.DateOfWarrantyExp);
            cmd.Parameters.AddWithValue("@InWarranty", b.InWarranty);
            cmd.Parameters.AddWithValue("@Price", b.Price);
            cmd.Parameters.AddWithValue("@SpecialWarranty", b.SpecialWarranty);
            cmd.Parameters.AddWithValue("@IsActive", b.IsActive);
            cmd.Parameters.AddWithValue("@Deviceid", b.DeviceId);
                    
            int rowUpdate = cmd.ExecuteNonQuery();
            con.Close();
            if (rowUpdate != 0)
            {
                return (true);
            }
            else
            {
                return (false);
            }
       }

        //public int deletedetails(BOclass b)
        //{
        //  SqlConnection con = new SqlConnection("data source=172.25.192.80;initial catalog=DB01HMS22;password=tcshyd;user id=pj01hms22");
        //SqlCommand cmd = new SqlCommand("usp_phone_details_delete", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //if (con.State != ConnectionState.Open)
        //  con.Open();
        //cmd.Parameters.AddWithValue("@id", b.id);
        //cmd.Parameters.AddWithValue("@name", b.name);
        //int r = cmd.ExecuteNonQuery();
        //con.Close();
        //return r;

        //}


        /////////////////////////////////View warranty details//////////////////////////////////////////////////////

        public List<BO_Warranty> viewdetails()
        {
            List<BO_Warranty> bo = new List<BO_Warranty>();
            //create connection object:
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_ViewWarrantyMaintenance", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State != ConnectionState.Open)
                con.Open();
            cmd.Parameters.AddWithValue("@IsActive", true);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    BO_Warranty cl = new BO_Warranty();
                    cl.DeviceId = Convert.ToInt32(dr["Deviceid"]);
                    cl.DeviceName = dr["DeviceName"].ToString();
                    cl.DateOfManufacture = Convert.ToDateTime(dr["DateofManufacture"]);
                    cl.DeviceType = dr["DeviceType"].ToString();
                    cl.ModelNo = dr["ModelNo"].ToString();
                    cl.IMEI = Convert.ToInt32(dr["IMEINumber"]);
                    cl.DateOfShipping = Convert.ToDateTime(dr["DateofShipping"]);
                    cl.DateOfWarrantyExp = Convert.ToDateTime(dr["DateofWarrantyExpiry"]);
                    cl.InWarranty = dr["InWarranty"].ToString();
                    cl.Price = Convert.ToInt64(dr["Price"]);

                    bo.Add(cl);
                }
            }
            con.Close();
            return bo;
        }

        /////////////view warrenty with filter: InWarranty,DevType,IsActive////////////////////////////
        public List<BO_Warranty> viewby(BO_Warranty bow)
        {
            List<BO_Warranty> bo = new List<BO_Warranty>();
            //create connection object:
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_ViewWarrantyMaintenance", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.Parameters.AddWithValue("@IsActive", true);
            cmd.Parameters.AddWithValue("@InWarranty",bow.InWarranty );
            cmd.Parameters.AddWithValue("@DeviceType", bow.DeviceType);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int id = Convert.ToInt32(dr["Deviceid"]);
                string name = dr["DeviceName"].ToString();
                DateTime dom = Convert.ToDateTime(dr["DateofManufacture"]);
                string DevType = dr["DeviceType"].ToString();
                string modelno = dr["ModelNo"].ToString();
                long IMEI = Convert.ToInt32(dr["IMEINumber"]);
                DateTime DateofShipping = Convert.ToDateTime(dr["DateofShipping"]);
                DateTime DateofWarrantyExpiry = Convert.ToDateTime(dr["DateofWarrantyExpiry"]);
                string InWarranty = dr["InWarranty"].ToString();
                double Price = Convert.ToInt64(dr["Price"]);
                string SpecialWarranty = dr["SpecialWarranty"].ToString();


                BO_Warranty cl = new BO_Warranty(name, modelno, DevType, IMEI, dom, DateofShipping, DateofWarrantyExpiry, InWarranty, Price, SpecialWarranty, id);
                bo.Add(cl);
            }
            con.Close();
            return bo;
        }
        /////////////////////////////////////Search by IMEI, dom, DateofShipping, id///////////////////////
        public List<BO_Warranty> searchwarranty(BO_Warranty bosearch)
        {
            List<BO_Warranty> bo = new List<BO_Warranty>();
            //create connection object:
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_SearchWarrantyMaintenance", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (con.State != ConnectionState.Open)
                con.Open();

            cmd.Parameters.AddWithValue("@IMEINumber",bosearch.IMEI );
            cmd.Parameters.AddWithValue("@DateofManufacture",bosearch.DateOfManufacture );
            cmd.Parameters.AddWithValue("@DateofShipping",bosearch.DateOfShipping );
            cmd.Parameters.AddWithValue("@Deviceid",bosearch.DeviceId );
           
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int id = Convert.ToInt32(dr["Deviceid"]);
                string name = dr["DeviceName"].ToString();
                DateTime dom = Convert.ToDateTime(dr["DateofManufacture"]);
                string DevType = dr["DeviceType"].ToString();
                string modelno = dr["ModelNo"].ToString();
                long IMEI = Convert.ToInt32(dr["IMEINumber"]);
                DateTime DateofShipping = Convert.ToDateTime(dr["DateofShipping"]);
                DateTime DateofWarrantyExpiry = Convert.ToDateTime(dr["DateofWarrantyExpiry"]);
                string InWarranty = dr["InWarranty"].ToString();
                double Price = Convert.ToInt64(dr["Price"]);
                string SpecialWarranty = dr["SpecialWarranty"].ToString();
                bool IsActive = Convert.ToBoolean(dr["IsActive"]);

                BO_Warranty cl = new BO_Warranty(name, modelno, DevType, IMEI, dom, DateofShipping, DateofWarrantyExpiry, InWarranty, Price, SpecialWarranty, id, IsActive);
                bo.Add(cl);
            }
            con.Close();
            return bo;
        }
    }
}
     