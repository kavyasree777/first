﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Basic_Operation;
using Data_Acess;

namespace Bussiness_Class
{
    
        public class BLLMaintenance
        {
            DAL dl = new DAL();
            
            public int ASV_addition(BO_ASV b1)
            {
                return dl.AddASV(b1);
            }
            public bool ASV_Editing(BO_ASV b2)
            {
                return dl.ASV_Edit(b2);
            }
            public int ASV_Viewing()
            {
                return Convert.ToInt32(dl.ViewASV());
            }
            public void ASV_Deleting(int ASVid)
            {
                dl.DeleteASV(ASVid);
            }
            public List<BO_ASV> Search_ASV(BO_ASV b3)
            {
                return (dl.Search_ASV(b3));
            }
//----------------------------------------BLL FOR RCM----------------------------------------
            public int Add_RCM_Details(BO_RCM bo)
            {
                return (dl.Add_RCM_Details(bo));
            }

            public bool Update_RCM_Details(BO_RCM bo)
            {
                return (dl.Update_RCM_Details(bo));
            }

            public List<BO_RCM> Search_RCM_Details(BO_RCM bo)
            {
                return (dl.Search_RCM_Details(bo));
            }

            public List<BO_RCM> View_RCM_Details(BO_RCM bo)
            {
                return (dl.View_RCM_Details(bo));
            }

            public bool Delete_RCM_Details(BO_RCM bo)
        {
                return (dl.Delete_RCM_Details(bo));
            }


            //----------------bll for warranty---------------------------------------------------

            public int adddetails(BO_Warranty b)
            {
                return (dl.adddetails(b));
            }

            public bool updatedetails(BO_Warranty b)
            {
                return (dl.updatedetails(b));
            }

            public List<BO_Warranty> viewdetails()
            {
                return (dl.viewdetails());
            }

            public List<BO_Warranty> viewby(BO_Warranty bow)
            {
                return (dl.viewby(bow));
            }

            public List<BO_Warranty> searchwarranty(BO_Warranty bosearch)
            {
                return (dl.searchwarranty(bosearch));
            }


        }








    
}
