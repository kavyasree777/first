﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class reader1
    {
        private int Userid;

        public int userid
        {
            get { return Userid; }
            set { Userid = value; }
        }
        private string UserName;

        public string username
        {
            get { return UserName; }
            set { UserName = value; }
        }
        public reader1()
        { }
        public reader1(string username, int userid)
        {
            this.username = username;
            this.userid = userid;
        }
       
    }
}