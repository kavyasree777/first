﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

using System.Data;

namespace UIProject
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        //string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";
        DAL dal = new DAL();
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            TextBox_Loginid.Text = TextBox_Password.Text = "";


        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            
            int userid = Convert.ToInt32(TextBox_Loginid.Text);
            string password = TextBox_Password.Text;

            Register robj = new Register(userid, password);
            robj.password = password;
            robj.userid = userid;
            bool result=dal.CheckAvailability(robj);
            
            if(result)
            {
                Session["value"] = userid;
                Response.Redirect("~/ProductOrder.aspx");
               
            }
            else
            {
                Response.Write("<script>alert ('Check Userid and Password')</script>");
            }
           


        }

        protected void TextBox_Loginid_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
        {

        }

        
        //int userid = Convert.ToInt32(TextBox_Loginid.Text);
        //string password = TextBox_Password.Text;

        // SqlConnection con = new SqlConnection();
        //SqlCommand cmd = new SqlCommand("select Userid, Password1 from register_table where Userid=@user and Password1=@pwd", con);
        //  cmd.Parameters.AddWithValue("@user", TextBox_Loginid.Text);
        // cmd.Parameters.AddWithValue("@pwd", TextBox_Password.Text);
        // if (con.State ==ConnectionState.Closed)
        // con.Open();
        // string user = TextBox_Loginid.Text;
        // SqlDataAdapter da = new SqlDataAdapter(cmd);
        // DataTable dt = new DataTable();
        // da.Fill(dt);
        // if (dt.Rows.Count > 0)
        // {
        //     Session["Userid"] = user;
        //     con.Close();
        //     Response.Redirect("ProductOrder.aspx");
        // }
        // else
        // {
        //     con.Close();
        //     ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
        // }

    }
}