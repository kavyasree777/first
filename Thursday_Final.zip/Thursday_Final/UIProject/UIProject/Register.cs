﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class Register
    {
        int  Userid;
        string CompanyName ;
       
        
        public int userid
        {
            get { return Userid; }
            set { Userid = value; }
        }
              

        public string companyName
        {
            get { return CompanyName; }
            set { CompanyName = value; }
        }
        private string CompanyDescription;

        public string companyDescription
        {
            get { return CompanyDescription; }
            set { CompanyDescription = value; }
         }

        private string UserName;

        public string userName
        {
            get { return UserName; }
            set { UserName = value; }
        }

        private string Password1;

        public string password
        {
            get { return Password1; }
            set { Password1 = value; }
        }

        private string Address1;

        public string address
        {
            get { return Address1; }
            set { Address1 = value; }
        }

        private string Country;

        public string country
        {
            get { return Country; }
            set { Country = value; }
        }

        private string City;

        public string city
        {
            get { return City; }
            set { City = value; }
        }

        private DateTime CreatedOn;

        public DateTime createdOn
        {
            get { return CreatedOn; }
            set { CreatedOn = value; }
        }


        public Register()
        {

        }
        //for view
        public Register(string companyName,string companyDescription, string userName, string password, string address,string country, string city, DateTime createdOn, int userid)
        {
            this.companyName = companyName;
            this.companyDescription = companyDescription;
            this.userName = userName;
            this.password = password;
            this.address = address;
            this.country = country;
            this.city = city;
            this.createdOn = createdOn;
            this.userid = userid;

        }
        //for add
        public Register(string companyName,string companyDescription, string userName, string password, string address,string country, string city, DateTime createdOn)
        {
            this.companyName = companyName;
            this.companyDescription = companyDescription;
            this.userName = userName;
            this.password = password;
            this.address = address;
            this.country = country;
            this.city = city;
            this.createdOn = createdOn;
           
        }
        public Register (int userid, string password)
        {
            this.userid = userid;
            this.password = password;

        }
    }
}