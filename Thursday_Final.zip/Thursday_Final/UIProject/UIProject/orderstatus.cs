﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class orderStatus
    {
        private bool Order_status;

        public bool orderstatus
        {
            get { return Order_status; }
            set { Order_status = value; }
        }
        private long Orderid;

        public long orderid
        {
            get { return Orderid; }
            set { Orderid = value; }
        }
        
        public orderStatus()
        { }
        public orderStatus(bool order_status, long orderid)
        {
            this.orderstatus = order_status;
            this.orderid = orderid;
        }
    }
}