﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Configuration;

namespace UIProject
{
    public class DAL
    {
        string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";

        public bool CheckAvailability(Register robj)
        {
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_checkuser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Userid", robj.userid);
            cmd.Parameters.AddWithValue("@Password1", robj.password);

            //Register local = new Register();

            //SqlParameter result = cmd.Parameters.Add("@result", SqlDbType.Int);
            //result.Direction = ParameterDirection.Output;

                
            //cmd.ExecuteNonQuery();

            //con.Close();

            //if ((int)result.Value == 1)
            //    return true;
            //else
            //    return false;
            bool result = false;
            cmd.Parameters.AddWithValue("@result", 0);
            cmd.Parameters["@result"].Direction = ParameterDirection.Output;
            long rowaffected = cmd.ExecuteNonQuery();
            if (rowaffected != 0)
            {
                result = Convert.ToBoolean(cmd.Parameters["@result"].Value);
            }
            else
                result = true;
            con.Close();
            return result;

        }

        public long Regester_details(Register robj)
        {
            long Userid = 0;
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_register", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@CompanyName", robj.companyName);
            cmd.Parameters.AddWithValue("@CompanyDescription ", robj.companyDescription);
            cmd.Parameters.AddWithValue("@UserName", robj.userName);
            cmd.Parameters.AddWithValue("@Password1", robj.password);
            cmd.Parameters.AddWithValue("@Address1", robj.address);
            cmd.Parameters.AddWithValue("@CountryName", robj.country);
            cmd.Parameters.AddWithValue("@City", robj.city);
            cmd.Parameters.AddWithValue("@CreatedOn", robj.createdOn);

            cmd.Parameters.AddWithValue("@Userid", 0);
            cmd.Parameters["@Userid"].Direction = ParameterDirection.Output;


            long rowaffected = cmd.ExecuteNonQuery();
            if (rowaffected != 0)
            {
                Userid = Convert.ToInt64(cmd.Parameters["@Userid"].Value);
            }
            else
                Userid = 0;
            con.Close();
            return Userid;
        }

        public long Product_order(placeOrdr po,double totalcost)
        {
            long poid = 0;
            

            //string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_POrderDet_Insert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            //cmd.Parameters.AddWithValue("@POCategory", po.pocategory);
            cmd.Parameters.AddWithValue("@POCategory", po.pocategory);
            cmd.Parameters.AddWithValue("@BuyerName", po.buyername);
            cmd.Parameters.AddWithValue("@OrderDate", po.orderdate);
            cmd.Parameters.AddWithValue("@OrderFulfilDate", po.orderreqdate);
            cmd.Parameters.AddWithValue("@SupplierName", po.suppliername);
            cmd.Parameters.AddWithValue("@ItemName", po.itemname);
            cmd.Parameters.AddWithValue("@ItemDesc", po.itemdes);
            cmd.Parameters.AddWithValue("@Quantity", po.quantity);
            cmd.Parameters.AddWithValue("@UnitPrice", po.unitprice);
            DateTime datenow = po.orderdate;
            cmd.Parameters.AddWithValue("@POId", 0);
            cmd.Parameters["@POId"].Direction = ParameterDirection.Output;
            
            

            int rowaffected = cmd.ExecuteNonQuery();
            if (rowaffected != 0)
            {
                poid = Convert.ToInt64(cmd.Parameters["@POId"].Value);
                con.Close();

                cmd = new SqlCommand("usp_insertGridPO", con);
                  cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                long OrderId = poid;
                string Category = po.pocategory;
                string BuyerName = po.buyername;
                DateTime OrderDate = datenow;
                string SupplierName = po.suppliername;
                string ItemName = po.itemname;
                int Quantity = po.quantity;
                double UnitPrice = po.unitprice;

                cmd.Parameters.AddWithValue("@OrderId", OrderId);
                cmd.Parameters.AddWithValue("@Category", Category);
                cmd.Parameters.AddWithValue("@BuyerName", BuyerName);
                cmd.Parameters.AddWithValue("@OrderDate", OrderDate);
                cmd.Parameters.AddWithValue("@SupplierName", SupplierName);
                cmd.Parameters.AddWithValue("@ItemName", ItemName);
                cmd.Parameters.AddWithValue("@Quantity", Quantity);
                cmd.Parameters.AddWithValue("@UnitPrice", UnitPrice);
                cmd.Parameters.AddWithValue("@TotalCost", totalcost);
                //viewgrid vgaa = new viewgrid(OrderId, Category, BuyerName, OrderDate, SupplierName, ItemName, Quantity, UnitPrice, totalcost);
                
                //prod pro = new prod();
                //pro.databindingview(vgaa);

                cmd.ExecuteNonQuery();
                con.Close();

            }
            else
            {
                poid = 0;
                con.Close();
            }
            return poid;
        }

        public void order_reg(orderStatus o)
        {
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_orderstatus", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@Orderstatus", o.orderstatus);
            cmd.Parameters.AddWithValue("@orderid", o.orderstatus);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        //public string checkLogin (int userid)
        //{

        //    //string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
        //    SqlConnection con = new SqlConnection(str);
        //    SqlCommand cmd = new SqlCommand("usp_login", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    con.Open();
        //    cmd.Parameters.AddWithValue("@Userid", userid);

        //    SqlDataReader r = cmd.ExecuteReader();
        //    string pass = r["Password1"].ToString();

        //    bool result =cmd.ExecuteNonQuery();
        //    if ()

        //    con.Close();
        //    return pass;
        //}

        //view based on buyer name
        public List<viewgrid> View_Details(int poid)
        {
            List<viewgrid> po = new List<viewgrid>();

            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_viewGridPO", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@OrderId", poid);
            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.HasRows)  // true means table has some values
            {

                while (rd.Read())  // Read() method will read all data from table row by row.
                {
                    viewgrid o = new viewgrid();
                    o.orderid = Convert.ToInt32(rd["OrderId"]);
                    o.category = rd["Category"].ToString();
                    o.buyername = rd["BuyerName"].ToString();
                    o.orderdate = Convert.ToDateTime(rd["OrderDate"].ToString());
                    
                    o.suppliername = rd["SupplierName"].ToString();
                    o.itemname = rd["ItemName"].ToString();
                   
                    o.quantity = Convert.ToInt32(rd["Quantity"]);
                    o.unitprice = Convert.ToDouble(rd["UnitPrice"]);
                    o.totalcost = Convert.ToDouble(rd["TotalCost"]);
                    po.Add(o);
                }
            }
            con.Close();
            return po;
        }

        //view based on buyer name
        public List<viewgrid> View_Details1(string bname)
        {
            List<viewgrid> po = new List<viewgrid>();

            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_buyerview", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@BuyerName", bname);
            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.HasRows)  // true means table has some values
            {

                while (rd.Read())  // Read() method will read all data from table row by row.
                {
                    viewgrid o = new viewgrid();
                    o.orderid = Convert.ToInt32(rd["OrderId"]);
                    o.category = rd["Category"].ToString();
                    o.buyername = rd["BuyerName"].ToString();
                    o.orderdate = Convert.ToDateTime(rd["OrderDate"].ToString());

                    o.suppliername = rd["SupplierName"].ToString();
                    o.itemname = rd["ItemName"].ToString();

                    o.quantity = Convert.ToInt32(rd["Quantity"]);
                    o.unitprice = Convert.ToDouble(rd["UnitPrice"]);
                    o.totalcost = Convert.ToDouble(rd["TotalCost"]);
                    po.Add(o);
                }
            }
            con.Close();
            return po;
        }


    }
}