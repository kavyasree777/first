﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class viewgrid
    {
        private long Orderid;

        public long orderid
        {
            get { return Orderid; }
            set { Orderid = value; }
        }

        private string Category;

        public string category
        {
            get { return Category; }
            set { Category = value; }
        }
        private string BuyerName;

        public string buyername
        {
            get { return BuyerName; }
            set { BuyerName = value; }
        }
        private DateTime OrderDate;

        public DateTime orderdate
        {
            get { return OrderDate; }
            set { OrderDate = value; }
        }
        private string SupplierName;

        public string suppliername
        {
            get { return SupplierName; }
            set { SupplierName = value; }
        }
        private string ItemName;

        public string itemname
        {
            get { return ItemName; }
            set { ItemName = value; }
        }
        private int Quantity;

        public int quantity
        {
            get { return Quantity; }
            set { Quantity = value; }
        }
        private double Unitprice;

        public double unitprice
        {
            get { return Unitprice; }
            set { Unitprice = value; }
        }
        private double Totalcost;

        public double totalcost
        {
            get { return Totalcost; }
            set { Totalcost = value; }
        }
        public viewgrid()
        { }
        public viewgrid(long Orderid,string Category,string buyername,DateTime OrderDate,string SupplierName,string ItemName,int quantity,double Unitprice,double Totalcost)
        {
            this.orderid = orderid;
            this.category = category;
            this.buyername = buyername;
            this.orderdate = orderdate;
            this.suppliername = suppliername;
            this.itemname = itemname;
            this.quantity = quantity;
            this.unitprice = unitprice;
            this.totalcost = totalcost;
        }
    }
}