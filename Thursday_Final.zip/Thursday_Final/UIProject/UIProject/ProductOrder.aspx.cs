﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UIProject
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";
        DAL dal = new DAL();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["value"] == null)
            {
                Response.Redirect("~/Loginpage.aspx");
            }
            else
            {

                //for loading today date in order date
                DateTime todaydate = DateTime.Now;
                string date = todaydate.ToShortDateString();
                TextBox_orderDate.Text = date;

               

            }
                //for dropdown list connection and adding data            
                //List<reader1> buyerlist = new List<reader1>();

                //SqlConnection con = new SqlConnection(str);
                //SqlCommand cmd = new SqlCommand("usp_buyerdetails", con);
                //cmd.CommandType = CommandType.StoredProcedure;
                //con.Open();
                //SqlDataReader r = cmd.ExecuteReader();

                ////string abc = "-select-";
                ////buyerlist.Add(abc);

                //while (r.Read())
                //{
                //    reader1 r1 = new reader1();
                //    r1.username = r["UserName"].ToString();
                //    r1.userid = Convert.ToInt32(r["Userid"].ToString());

                //    buyerlist.Add(r1);              

                //}
                ////DropDownList_city.DataSource = buyerlist;
                ////DropDownList_city.DataBind();
                ////cmd.ExecuteNonQuery();

                //DropDownList_buyer.DataSource = buyerlist;

                //DropDownList_buyer.DataTextField = "username";

                //DropDownList_buyer.DataValueField = "userid";

                //DropDownList_buyer.DataBind();

                //con.Close();
           


        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {
            DateTime orderdate = Convert.ToDateTime(TextBox_orderDate.Text);
            DateTime reqdate = Convert.ToDateTime(TextBox_reqDate.Text);
            if (reqdate < orderdate)
            {
                Response.Write("<script>alert('Required Date should be greater than Ordered date')</script>");
            }
        }

        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {
            //if (DropDownList_category.SelectedValue == "Services")
            //{
            //    TextBox_quantity.Enabled = false;
            //}
        }

        protected void TextBox_unitPrice_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double unitPrice = double.Parse(TextBox_unitPrice.Text);
            double quantity = 1;
            if (TextBox_quantity.Enabled)
            {
                quantity = double.Parse(TextBox_quantity.Text);
            }
            double totalCost = unitPrice * quantity;

            string pocategory = DropDownList_category.SelectedValue;
            string buyername = DropDownList_buyer.SelectedValue;
            DateTime orderdate = Convert.ToDateTime(TextBox_orderDate.Text); 
            DateTime orderreqdate = Convert.ToDateTime(TextBox_reqDate.Text);
            string suppliername = TextBox_supplier.Text;
            string itemname = DropDownList_itemName.SelectedValue;
            string itemdes = TextBox_itemdesc.Text;
            int quantity1 = 1;
            if (TextBox_quantity.Enabled)
            {
                quantity1 = Convert.ToInt32(TextBox_quantity.Text);
            }
            double unitprice = Convert.ToDouble(TextBox_unitPrice.Text);

            placeOrdr p = new placeOrdr(pocategory, buyername, orderdate, orderreqdate, suppliername, itemname, itemdes, quantity1, unitPrice);
            
            long poid = dal.Product_order(p,totalCost);
            orderStatus os = new orderStatus();
            os.orderid = poid;
            os.orderstatus = false;
            dal.order_reg(os);

            if (poid > 0)

                Response.Write("<script> alert('Your order no is :" + poid + "Total cost of your order is :" + totalCost + "') </script>");
            DropDownList_category.SelectedIndex = 0;
            DropDownList_buyer.SelectedIndex = 0;
            TextBox_reqDate.Text = "";
            TextBox_supplier.SelectedIndex = 0;
            TextBox_unitPrice.Text = "";
            TextBox_quantity.Text = "";
            TextBox_itemdesc.Text = "";
            DropDownList_itemName.SelectedIndex = 0;

        }

        protected void DropDownList_category_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList_category.SelectedValue == "Services")
            {
                TextBox_quantity.Text = "1";
                TextBox_quantity.Enabled = false;

            }
            else
            {
                TextBox_quantity.Enabled = true;
            }
        }

        protected void DropDownList_itemName_SelectedIndexChanged(object sender, EventArgs e)
        {
            double Price;
            if (DropDownList_itemName.SelectedIndex == 0 )
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 10000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 5005.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }

            else if (DropDownList_itemName.SelectedIndex == 1)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 20000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 12005.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }

            else if (DropDownList_itemName.SelectedIndex == 2)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 1000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 7005.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }
            else if (DropDownList_itemName.SelectedIndex == 3)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 5000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 2005.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }
            else if (DropDownList_itemName.SelectedIndex == 4)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 3000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 1505.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }
            else if (DropDownList_itemName.SelectedIndex == 5)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 7000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 3505.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }
            else if (DropDownList_itemName.SelectedIndex == 6)
            {
                if (DropDownList_category.SelectedValue == "Goods")
                {
                    Price = 5000.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
                else if (DropDownList_category.SelectedValue == "Services")
                {
                    Price = 2505.00;
                    TextBox_unitPrice.Text = Price.ToString();
                }
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void Button_Reset(object sender, EventArgs e)
        {
            DropDownList_category.SelectedIndex = 0;
            DropDownList_buyer.SelectedIndex = 0;
            TextBox_reqDate.Text = "";
            TextBox_supplier.SelectedIndex = 0;
            TextBox_unitPrice.Text = "";
            TextBox_quantity.Text = "";
            TextBox_itemdesc.Text = "";
            DropDownList_itemName.SelectedIndex = 0;

        }

        protected void TextBox_itemdesc_TextChanged(object sender, EventArgs e)
        {

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["value"] = null;
            Response.Redirect("~/Loginpage.aspx");
        }

        
    }
}