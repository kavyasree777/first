﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class placeOrdr
    {
        private int PONo;

        public int pono
        {
            get { return PONo; }
            set { PONo = value; }
        }
        private string POCategory;

        public string pocategory
        {
            get { return POCategory; }
            set { POCategory = value; }
        }
        private string BuyerName;

        public string buyername
        {
            get { return BuyerName; }
            set { BuyerName = value; }
        }
        private DateTime OrderDate;

        public DateTime orderdate
        {
            get { return OrderDate; }
            set { OrderDate = value; }
        }
        private DateTime OrderReqDate;

        public DateTime orderreqdate
        {
            get { return OrderReqDate; }
            set { OrderReqDate = value; }
        }
        private string SupplierName;

        public string suppliername
        {
            get { return SupplierName; }
            set { SupplierName = value; }
        }
        private string ItemName;

        public string itemname
        {
            get { return ItemName; }
            set { ItemName = value; }
        }
        private string ItemDes;

        public string itemdes
        {
            get { return ItemDes; }
            set { ItemDes = value; }
        }
        private int Quantity;

        public int quantity
        {
            get { return Quantity; }
            set { Quantity = value; }
        }
        private double UnitPrice;

        public double unitprice
        {
            get { return UnitPrice; }
            set { UnitPrice = value; }
        }
        public placeOrdr()
        { }
        public placeOrdr(string pocategory, string buyername, DateTime orderdate, DateTime orderreqdate, string suppliername, string itemname, string itemdes, int quantity, double unitprice)
        {
            this.pono = pono;
            this.pocategory = pocategory;
            this.buyername = buyername;
            this.orderdate = orderdate;
            this.orderreqdate = orderreqdate;
            this.suppliername = suppliername;
            this.itemname = itemname;
            this.itemdes = itemdes;
            this.quantity = quantity;
            this.unitprice = unitprice;
        }
        public placeOrdr(int pono,string pocategory, string buyername, DateTime orderdate, DateTime orderreqdate, string suppliername, string itemname, string itemdes, int quantity, double unitprice)
        {
            this.pono = pono;
            this.pocategory = pocategory;
            this.buyername = buyername;
            this.orderdate = orderdate;
            this.orderreqdate = orderreqdate;
            this.suppliername = suppliername;
            this.itemname = itemname;
            this.itemdes = itemdes;
            this.quantity = quantity;
            this.unitprice = unitprice;
        }
    }
}