﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UIProject
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            TextBox_Aname.Text = TextBox_Apwd.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string Aname = TextBox_Aname.Text;
            string Apwd = TextBox_Apwd.Text;

            if (Aname == "ADMIN")
            { if (Apwd=="ADMIN@123")
                {
                    Response.Redirect("~/AdminEntry.aspx");
                }
            else
                    Response.Write("<script>alert('Check the Admin Password')</script>");
            }
            else
            {
                Response.Write("<script>alert('Check the Admin Name')</script>");
            }

        }
    }
}