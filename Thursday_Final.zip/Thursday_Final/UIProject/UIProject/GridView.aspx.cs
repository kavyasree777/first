﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace UIProject
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        DAL dal = new DAL();


        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["value"]==null)
            {
                Response.Redirect("~/Loginpage.aspx");
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //List<placeOrdr> pi = new List<placeOrdr>();
            int poid = Convert.ToInt32(TextBox_userid.Text);

           
            GridView1.DataSource = dal.View_Details(poid); 
            GridView1.DataBind();
            int rowCount = GridView1.Rows.Count; // returns ROW count
            if(rowCount==0)
            {
                Response.Write("<script>alert ('NO SUCH PRODUCT DETAILS EXIST')</script>");
            }
            TextBox_userid.Text = "";
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";
            
            SqlConnection con = new SqlConnection(str);
            SqlCommand cmd = new SqlCommand("usp_deleteview", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@OrderId", GridView1.DataKeys[e.RowIndex].Values["OrderId"]);
            cmd.ExecuteNonQuery();
            con.Close();
            GridView1.DataBind();
            
        }

        protected void Button_buyer_Click(object sender, EventArgs e)
        {
            string buyer = (TextBox_bname.Text);

            GridView1.DataSource = dal.View_Details1(buyer); 
            GridView1.DataBind();

            int rowCount = GridView1.Rows.Count; // returns zero
            if (rowCount == 0)
            {
                Response.Write("<script>alert ('NO SUCH BUYER DETAILS EXIST')</script>");
            }
            TextBox_bname.Text = "";

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["value"] = null;
            Response.Redirect("~/Loginpage.aspx");

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != GridView1.EditIndex)
            {
                (e.Row.Cells[0].Controls[0] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";

            }
        }

        
    }
}