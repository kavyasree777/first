﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace UIProject
{
    public class prod
    {
        //string str = "Data Source=172.25.192.80;uid=pj01hms22;pwd=tcshyd;database=db01hms22";

        public void databindingview(viewgrid vg)
        {
        //SqlConnection con = new SqlConnection(str);
        //    SqlCommand cmd = new SqlCommand("usp_viewGridPO", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    con.Open();
            
        //    cmd.Parameters.AddWithValue("@OrderId",vg.orderid);
        //    cmd.Parameters.AddWithValue("@Category", vg.category);
        //    cmd.Parameters.AddWithValue("@BuyerName", vg.buyername);
        //    cmd.Parameters.AddWithValue("@OrderDate", vg.orderdate);
        //    cmd.Parameters.AddWithValue("@SupplierName", vg.suppliername);
        //    cmd.Parameters.AddWithValue("@ItemName", vg.itemname);
        //    cmd.Parameters.AddWithValue("@Quantity", vg.quantity);
        //    cmd.Parameters.AddWithValue("@UnitPrice", vg.unitprice);
        //    cmd.Parameters.AddWithValue("@TotalCost", vg.totalcost);

        //     cmd.ExecuteNonQuery();
        //    con.Close();
            
            

        }
    }
}