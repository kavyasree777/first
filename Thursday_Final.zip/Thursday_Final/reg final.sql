create table register_table
(
Userid unique identity(201,1),
CompanyName varchar(20) not null,
CompanyDescription varchar(100),
UserName varchar(25) not null,
Password1 varchar(10) not null,
Address1 varchar(100),
CountryName varchar(15) not null,
City varchar(15) not null,
CreatedOn datetime
)

select*from register_table
truncate table register_table
drop table register_table

create table tbl_ProductOrderDetails(POId bigint primary key identity(1,1),
				POCategory varchar(10),
				BuyerName varchar(20),
				OrderDate date,
				OrderFulfilDate date,
				SupplierName varchar(25),
				ItemName varchar(25),
				ItemDesc varchar(61),
				Quantity int ,
				UnitPrice money);


create table country_city
(
CountryName varchar(10),
City varchar(10)
)
select *from country_city
insert into country_city values ('India','Hyderabad'),('India','Bangalore'),('India','Chennai'),('India','Mumbai'),('India','Delhi'),('India','Kolkata');
insert into country_city values ('USA','Washington'),('USA','Dallas'),('USA','Queens'),('USA','Texas'),('USA','NewYork');
insert into country_city values ('Australia','Perth'),('Australia','Sydney'),('Australia','Melbourne'),('Australia','Adelaide');



create proc usp_city
(
@CountryName varchar(10)
)
as 
begin
select City from country_city where CountryName=@CountryName
end


create procedure usp_register(@CompanyName  varchar(20),
@CompanyDescription varchar(100),
@UserName varchar(25),
@Password1 varchar(10),
@Address1 varchar(100),
@CountryName varchar(15),
@City varchar(15),
@CreatedOn datetime,
@Userid int out)
as 
begin
insert into register_table values (@CompanyName,@CompanyDescription,
@UserName,@Password1,@Address1,@CountryName,@City,@CreatedOn);
set @Userid=@@IDENTITY
end


drop proc usp_POrderDet_Insert
create proc usp_POrderDet_Insert
				(@POCategory varchar(10),
				@BuyerName varchar(20),
				@OrderDate date,
				@OrderFulfilDate date,
				@SupplierName varchar(25),
				@ItemName varchar(25),
				@ItemDesc varchar(61),
				@Quantity int ,
				@UnitPrice money,
				@POId bigint out )
as
begin
insert into tbl_ProductOrderDetails values(
				@POCategory ,
				@BuyerName ,
				@OrderDate ,
				@OrderFulfilDate ,
				@SupplierName ,
				@ItemName ,
				@ItemDesc ,
				@Quantity  ,
				@UnitPrice ) 
set @POId=@@IDENTITY
end  
select *from tbl_ProductOrderDetails

exec usp_POrderDet_Insert 'asd','asdff','02/15/2011','02/15/2010','dayhsf','agjfasysk','fsskyifstd',2,1000,null
select *from tbl_ProductOrderDetails
create proc usp_POrderDet_view
as
begin
select * from tbl_ProductOrderDetails
end



--Procedure for Viewing OrderrDetais based on ID
create proc usp_OrderDetails_View(@Userid int out)
as
begin
select *from register_table where Userid=@Userid
end


--------------------------------------------------
create procedure usp_buyerdetails
as
begin
select Userid,UserName from register_table 
end
exec  usp_buyerdetails


-------------------------
create table order_tbl
(
order_status bit,
orderid bigint
)
drop table order_tbl
drop table order_tbl

create proc usp_orderstatus(@Orderstatus bit, @orderid bigint)
as
begin
insert into order_tbl values (@Orderstatus, @orderid )
end

------------------------------------------------------------------------
create proc usp_login(@Userid int)
as
begin
select Password1 from register_table where Userid = @Userid

end
exec usp_login 202
-------------------------------------------------------------




create proc usp_OrderDetails_View
(@poid bigint
)
as 
begin
select *  from tbl_ProductOrderDetails where POId=@poid
end

--POId,POCategory,OrderDate,OrderFulfilDate ,SupplierName,ItemName,ItemDesc,Quantity, UnitPrice
----------------------------------------------------------------------------------------
create procedure usp_checkuser(@Userid bigint,@Password1 varchar(10),@result int out)
as
begin
if not exists (select Userid,Password1 from register_table where Userid=@Userid and Password1=@Password1)
	set @result=0
else
	set @result=1
end

declare @result int
exec usp_checkuser 'akshay','Ps09@athif', @result out
print @result
truncate table tbl_ProductOrderDetails

------------------------------------------------
create procedure usp_checkuser(@Userid bigint,@Password1 varchar(10))
as
begin
select Userid,Password1 from register_table 
end
-----------------------------------------------------------------------
create table tbl_ProductOrderView(OrderId bigint ,
				Category varchar(10),
				BuyerName varchar(20),
				OrderDate date,
				SupplierName varchar(25),
				ItemName varchar(25),
				Quantity int ,
				UnitPrice money,
				TotalCost money);

create proc usp_viewGridPO (
				@OrderId bigint 
				)
as
begin
select * from tbl_ProductOrderView where OrderId=@OrderId
end
create proc usp_insertGridPO (
				@OrderId bigint ,
				@Category varchar(10),
				@BuyerName varchar(20),
				@OrderDate date,
				@SupplierName varchar(25),
				@ItemName varchar(25),
				@Quantity int ,
				@UnitPrice money,
				@TotalCost money)
as
begin
insert into tbl_ProductOrderView values (@OrderId ,
				@Category, 
				@BuyerName ,
				@OrderDate ,
				@SupplierName,
				@ItemName,
				@Quantity ,
				@UnitPrice,
				@TotalCost)

end
exec usp_insertGridPO 123,'goods','asd','01/01/2017','ddd','ddd',1,123,123
exec usp_insertGridPO 124,'goods','asd','01/01/2017','ddd','ddd',1,123,123
exec usp_insertGridPO 125,'goods','ad','01/01/2017','ddd','ddd',1,123,123
-------------------------------------------------------------------------
create proc usp_deleteview (
				@OrderId bigint 
				)
as
begin
delete tbl_ProductOrderView where OrderId=@OrderId
end
exec usp_buyerview 'asd'
select * from tbl_ProductOrderView
---------------------------------------------------
create proc usp_buyerview (
				@BuyerName varchar(20)
				)
as
begin
select *from  tbl_ProductOrderView where BuyerName=@BuyerName
end
--truncate table tbl_ProductOrderView
